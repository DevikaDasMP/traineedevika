# Week #4: Course Materials

The objective of week #4 is to complete the Cli implementation for all the functionalities and add Test cases using Junit and Jmockit. 

## Java

## Junit

## Jmockit

### Work on adding unit tests
    * One person to make mvn package succeed - add Menu tests
    * Others to add tests for Order etc.

### Tests for the cli

### Basic tests
    * Invalid input for the data type
    * Including for the menu option
    * Non-existing employee id
    * Apply wallet balance not sufficient
    * Order placed <-> Order Processed <-> Order Cancelled three-way state transitions
 
