package com.hexaware.MLP156;

import com.hexaware.MLP156.persistence.VendorDAO;
import com.hexaware.MLP156.factory.VendorFactory;
import com.hexaware.MLP156.model.Vendor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for Vendor.
 */
@RunWith(JMockit.class)
public class VendorTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {

  }
  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testVendor() {
    Vendor m = new Vendor();
    Vendor m100 = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160);
    Vendor m101 = new Vendor(2002, "Sar", "sara", "456", "sar@gmail.com", "3322115596", "House No:27", 30);
    assertNotEquals(m100, null);
    assertNotEquals(m101, null);
    assertEquals(m100.getVendoorId(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVendoorId());
    assertEquals(m100.getVenName(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenName());
    assertEquals(m100.getVenUsername(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenUsername());
    assertEquals(m100.getVenPassword(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenPassword());
    assertEquals(m100.getVenEmail(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenEmail());
    assertEquals(m100.getVenMobileno(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenMobileno());
    assertEquals(m100.getVenAddress(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenAddress());
    assertEquals(m100.getVenWallet(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).getVenWallet(), 0.001);
    m101.setVendoorId(2003);
    m101.setVenName("sah");
    m101.setVenUsername("sahi");
    m101.setVenPassword("234");
    m101.setVenEmail("sah@gmail.com");
    m101.setVenMobileno("3456789021");
    m101.setVenAddress("house no:21");
    m101.setVenWallet(300);
    assertEquals(m100, new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160));
    assertNotEquals(m100, new Vendor(2002, "Sar", "sara", "456", "sar@gmail.com", "3322115596", "House No:27", 30));
    assertEquals(m100.hashCode(),
        new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).hashCode());
    assertEquals(m100.toString(), new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160).toString());
  }

  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testvalidateVLogin(@Mocked final VendorDAO dao) {
    final Vendor ven = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160.0);
    new Expectations() {
      {
        dao.validateVLogin("SJ007", "SJ007");
        result = ven;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    Vendor ven1 = VendorFactory.validateVLogin("SJ007", "SJ007");
    assertEquals(ven, ven1);
  }


  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testshowMenu(@Mocked final VendorDAO dao) {
    final Vendor ven = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160.0);
    final ArrayList<Vendor> mn = new ArrayList<Vendor>();
    new Expectations() {
      {
        mn.add(ven);
        dao.show();
        result = mn;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };

    Vendor[] ven1 = VendorFactory.showMenu();
    assertEquals(1, ven1.length);
  }


 /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testvenwalletbal(@Mocked final VendorDAO dao) {
    final Vendor ven = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160.0);
    new Expectations() {
      {
        double val = dao.venwalletbal(2001);
        result = 160;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    int ven1 = VendorFactory.venwalletbal(2001);
    assertEquals(160, ven1);
  }

 /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testvenwalletbalnce(@Mocked final VendorDAO dao) {
    final Vendor ven = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160.0);
    new Expectations() {
      {
        dao.venwalletbalce(2001);
        result = ven;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    Vendor ven1 = VendorFactory.venwalletbalnce(2001);
    assertEquals(ven, ven1);
  }


  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testupdatevendorwlt(@Mocked final VendorDAO dao) {
    final Vendor ven = new Vendor(2001, "Ram", "rama", "123", "ram@gmail.com", "8547140967", "House No:51", 160.0);
    int vId = ven.getVendoorId();
    new Expectations() {
      {
        Vendor vend = VendorFactory.venwalletbalnce(2001);
        double ventamt = vend.getVenWallet();
        int val = dao.venwalletupdate(2001, 160.0);
        result = 160;
      }
    };
    new MockUp<VendorFactory>() {
      @Mock
      VendorDAO dao() {
        return dao;
      }
    };
    int ven1 = VendorFactory.updatevendorwlt(ven, 160.0);
    assertEquals(160, ven1);
  }
}
