package com.hexaware.MLP156;

import com.hexaware.MLP156.persistence.OrdersDAO;
import com.hexaware.MLP156.factory.OrdersFactory;
import com.hexaware.MLP156.model.Menu;
import com.hexaware.MLP156.model.Orders;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Test class for Orders.
 */
@RunWith(JMockit.class)
public class OrdersTest {
  /**
   * @param sdf date format
   */
  private SimpleDateFormat sdf;

  /**
   * setup method.
   */
  @Before
  public final void initInput() {
    sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
  }

  /**
   * Tests the equals/hashcode methods of the employee class.
   *
   * @throws ParseException throws parseException
   */
  @Test
  public final void testOrders() throws ParseException {

    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);

    Orders o = new Orders();
    Orders o1 = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5);
    Orders o101 = new Orders(2, 1002, 3002, "onion masala dosa", "3", 300, d2, "d2", "CANCELLED", "WRONG ADDRESS", 0);
    assertNotEquals(o1, null);
    assertEquals(o1.getfoodId(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getfoodId());
    o101.setfoodId(1);
    assertEquals(o1.getordId(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordId());
    o101.setordId(1);
    assertEquals(o1.getempId(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getempId());
    o101.setempId(1001);
    assertEquals(o1.getordItem(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordItem());
    o101.setordItem("noodeles");
    assertEquals(o1.getordQty(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordQty());
    o101.setordQty("2");
    assertEquals(o1.getordAmnt(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordAmnt());
    o101.setordAmnt(250);
    assertEquals(o1.getordEst(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordEst());
    o101.setordEst("22/08/2019");
    assertEquals(o1.getordMsg(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordMsg());
    o101.setordMsg("TASTY");
    assertEquals(o1.getordStat(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordStat());
    o101.setordStat("PLACED");
    assertEquals(o1.getordRat(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordRat());
    o101.setordRat(4);
    assertEquals(o1.getordId(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).getordId());
    o101.setordId(4);

    assertNotEquals(o101,
        new Orders(1002, 3002, 0, "onion masala dosa", "3", 300, d2, "d2", "CANCELLED", "WRONG ADDRESS", 0));
    assertEquals(o1.hashCode(),
        new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5).hashCode());
    assertEquals(o1, new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "d2", "PLACED", "TASTY", 5));
  }

  /**
   * tests that empty employee list is handled correctly.
   *
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testshowOrders(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    final Orders ord1 = new Orders(2, 1002, 3002, "onion masala dosa", "3", 300, d2, "d2", "CANCELLED", "WRONG ADDRESS", 0);
    final ArrayList<Orders> od = new ArrayList<Orders>();
    new Expectations() {
      {
        od.add(ord);
        od.add(ord1);
        dao.show();
        result = od;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };

    Orders[] orde = OrdersFactory.showOrders();
    assertEquals(2, orde.length);
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testgetOrders(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    final Orders ord1 = new Orders(2, 1002, 3002, "onion masala dosa", "3", 300, d2, "d2", "CANCELLED", "WRONG ADDRESS",
        0);
    final ArrayList<Orders> od = new ArrayList<Orders>();
    new Expectations() {
      {
        od.add(ord);
        // od.add(ord1);
        dao.getAllPlacedOrders(3001);
        result = od;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders[] orde = OrdersFactory.getOrders(3001);
    final Orders ord2 = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    assertEquals(orde[0].getordId(), ord2.getordId());
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testgetvalidateOrders(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    new Expectations() {
      {
        dao.validategetOrders(3001);
        result = ord;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };

    Orders orde = OrdersFactory.getvalidateOrders(3001);
    assertEquals(ord, orde);
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testacceptOrders(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    new Expectations() {
      {
        dao.acceptOrderGivenId(1);
        result = 1;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };

    int orde = OrdersFactory.acceptOrders(1);
    assertEquals(1, orde);
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testrejectOrders(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    new Expectations() {
      {
        dao.rejectOrderGivenId(1, "not good");
        result = 1;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };

    int orde = OrdersFactory.rejectOrders(1, "not good");
    assertEquals(1, orde);
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testinsertIntoOrder(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    final Menu m100 = new Menu(3001, "noodeles", 2001, "VEG", "35", 250);
    new Expectations() {
      {
        String menuName = m100.getFoodName();
        int menuID = m100.getFoodId();
        dao.insertOrder(1001, menuID, menuName, 2, 250, "PLACED");
        result = 1;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    int orde = OrdersFactory.insertIntoOrder(1001, m100, 2, 250.0, "PLACED");
    assertEquals(1, orde);
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testvendororderhistory(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    final ArrayList<Orders> od = new ArrayList<Orders>();
    new Expectations() {
      {
        od.add(ord);
        dao.vendororderhistory(3001);
        result = od;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders[] orde = OrdersFactory.vendororderhistory(3001);
    final Orders ord3 = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    assertEquals(ord3.getordId(), orde[0].getordId());
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testemployeeorderhistory(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    new Expectations() {
      {
        dao.employeeorderhistory(1001);
        result = ord;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders[] orde = OrdersFactory.employeeorderhistory(1001);
    final Orders ord4 = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    assertEquals(orde[0].getordId(), ord4.getordId());
  }

  /**
   * @param dao mocking the dao class
   * @throws ParseException throws exception
   */
  @Test
  public final void testgetOrderdetails(@Mocked final OrdersDAO dao) throws ParseException {
    Date d3 = sdf.parse("2019-08-22");
    String d2 = sdf.format(d3);
    final Orders ord = new Orders(1, 1001, 3001, "noodeles", "2", 250, d2, "2019-08-22", "PLACED", "TASTY", 5);
    new Expectations() {
      {
        dao.getIdGivenOrderDetails(1);
        result = ord;
      }
    };
    new MockUp<OrdersFactory>() {
      @Mock
      OrdersDAO dao() {
        return dao;
      }
    };
    Orders orde = OrdersFactory.getOrderdetails(1);
    assertEquals(ord, orde);
  }
  /**
   * test Dao.
   */
  @Test
  public final void testDao() {
    Orders[] ord = OrdersFactory.showOrders();
    assertNotNull(ord);
  }

}
