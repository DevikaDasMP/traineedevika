package com.hexaware.MLP156;

import com.hexaware.MLP156.persistence.EmployeeDAO;
import com.hexaware.MLP156.factory.EmployeeFactory;
import com.hexaware.MLP156.model.Employee;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;
import java.util.ArrayList;

/**
 * Test class for Employee.
 */
@RunWith(JMockit.class)
public class EmployeeTest {
  /**
   * setup method.
   */
  @Before
  public void initInput() {

  }

  /**
   * Tests the equals/hashcode methods of the employee class.
   */
  @Test
  public final void testEmployee() {
    Employee e = new Employee();
    Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500);
    Employee e1002 = new Employee(1002, "Jayati Kochhar", "JayatiK ", "JayatiK", "jayatik@gmailcom", "123456789",
        "Chandigarh", 600);
    assertNotEquals(e1001, null);
    assertNotEquals(e1002, null);
    assertEquals(e1001.getEmpId(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpId());
    assertEquals(e1001.getEmpName(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpName());
    assertEquals(e1001.getEmpUserName(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500)
            .getEmpUserName());
    assertEquals(e1001.getEmpPwd(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpPwd());
    assertEquals(e1001.getEmpEmailId(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500)
            .getEmpEmailId());
    assertEquals(e1001.getEmpMobileNo(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500)
            .getEmpMobileNo());
    assertEquals(e1001.getEmpAdd(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpAdd());
    assertEquals(e1001.getEmpWlt(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpWlt(),
        0.001);
    e1002.setEmpId(1002);
    e1002.setEmpName("Jayati Kochhar");
    e1002.setEmpUserName("JayatiK");
    e1002.setEmpPwd("JayatiK");
    e1002.setEmpEmailId("jayatik@gmailcom");
    e1002.setEmpMobileNo("123456789");
    e1002.setEmpAdd("Chandigarh");
    e1002.setEmpWlt(600);
    assertEquals(e1001,
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500));
    assertNotEquals(e1001, new Employee(1002, "Jayati Kochhar", "JayatiK ", "JayatiK", "jayatik@gmailcom", "123456789",
        "Chandigarh", 600));
    assertEquals(e1001.hashCode(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).hashCode());
    assertEquals(e1001.toString(),
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).toString());
  }

  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class.
   */
  @Test
  public final void testListAllEmpty(@Mocked final EmployeeDAO dao) {
    new Expectations() {
      {
        dao.show();
        result = new ArrayList<Employee>();
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] me = EmployeeFactory.showEmployee();
    assertEquals(0, me.length);
  }

  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    final Employee e1002 = new Employee(1002, "Jayati Kochhar", "JayatiK ", "JayatiK", "jayatik@gmailcom", "123456789",
        "Chandigarh", 600);
    final ArrayList<Employee> mn = new ArrayList<Employee>();
    new Expectations() {
      {
        mn.add(e1001);
        mn.add(e1002);
        dao.show();
        result = mn;
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] mn1 = EmployeeFactory.showEmployee();
    assertEquals(2, mn1.length);
    assertEquals(
        new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune", 500).getEmpId(),
        mn1[0].getEmpId());
    assertEquals(
        new Employee(1002, "Jayati Kochhar", "JayatiK ", "JayatiK", "jayatik@gmailcom", "123456789", "Chandigarh", 600)
            .getEmpId(),
        mn1[1].getEmpId());
  }

  /**
   * @param dao mocking the dao class
   */
  @Test
  public final void testvalidateLogin(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        dao.validateLogin("SJ007", "SJ007");
        result = e1001;
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee emp = EmployeeFactory.validateLogin("SJ007", "SJ007");
    assertEquals(e1001, emp);
  }

  /**
   * @param dao mocking the dao class
   */
  @Test
  public final void testempwalletbal(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        dao.empwalletbal(1001);
        result = e1001.getEmpWlt();
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    double emp1 = EmployeeFactory.empwalletbal(1001);
    assertEquals(e1001.getEmpWlt(), emp1, 0.001);
  }

  /**
   * @param dao mocking the dao class
   */
  @Test
  public final void testvalidateWalletdetail(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        dao.validateWallet("SJ007", "SJ007");
        result = e1001;
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee emp2 = EmployeeFactory.validateWalletdetail("SJ007", "SJ007");
    assertEquals(e1001, emp2);
  }

  /**
   * @param dao mocking the dao class
   */
  @Test
  public final void testgetempdetails(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        dao.getallempdetails(1001);
        result = e1001;
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee emp4 = EmployeeFactory.getempdetails(1001);
    assertEquals(e1001, emp4);
  }

  /**
   * @param dao mocking the dao class
   */
  @Test
  public final void testamountUpdate(@Mocked final EmployeeDAO dao) {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        dao.amountUpdate((double) 500, 1001);
        result = 1;
      }
    };
    new MockUp<EmployeeFactory>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    int emp5 = EmployeeFactory.amountUpdate((double) 500, 1001);
    assertEquals(1, emp5);
  }

  /**
   * test validate wallet.
   */
  @Test
  public final void testvalidateWallet() {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        EmployeeFactory.validateWallet(e1001, 160.0);
        result = true;
      }
    };
    boolean emp6 = EmployeeFactory.validateWallet(e1001, 160.0);
    assertEquals(true, emp6);
  }

  /**
   * test validate wallet.
   */
  @Test
  public final void testvalidateWallets() {
    final Employee e1001 = new Employee(1001, "Smit Jakhotia", "SJ007", "SJ007", "smit@gmailcom", "123456789", "Pune",
        500);
    new Expectations() {
      {
        EmployeeFactory.validateWallet(e1001, 600.0);
        result = false;
      }
    };
    boolean emp6 = EmployeeFactory.validateWallet(e1001, 600.0);
    assertEquals(false, emp6);
  }
  /**
   * test dao.
   */
  @Test
  public final void testDao() {
    Employee[] eArray = EmployeeFactory.showEmployee();
    assertNotNull(eArray);
  }
}
