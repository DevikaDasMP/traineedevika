package com.hexaware.MLP156;

import com.hexaware.MLP156.persistence.MenuDAO;
import com.hexaware.MLP156.factory.MenuFactory;
import com.hexaware.MLP156.model.Menu;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

/**
 * Test class for Menu.
 */
@RunWith(JMockit.class)
public class MenuTest {
    /**
   * setup method.
   */
  @Before
  public void initInput() {
  }
  /**
   * Tests the equals/hashcode methods of the Menu class.
   */
  @Test
  public final void testMenu() {
    Menu m = new Menu();
    Menu m100 = new Menu(3001, "Idli", 2001, "VEG", "35", 39);
    Menu m101 = new Menu(3002, "Biriyani", 2002, "NON-VEG", "90", 348);
    assertNotEquals(m100, null);
    assertNotEquals(m101, null);
    assertEquals(m100.getFoodId(),
        new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodId());
    assertEquals(m100.getFoodName(),
        new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodName());
    assertEquals(m100.getFoodType(),
        new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodType());
    assertEquals(m100.getCalories(),
        new Menu(3001, "Idli", 2001, "VEG", "35", 39).getCalories());
    assertEquals(m100.getFoodAmt(),
        new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodAmt(), 0.001);
    m101.setFoodId(103);
    m101.setFoodName("noodles");
    m101.setVenId(204);
    m101.setFoodType("veg");
    m101.setCalories("105");
    m101.setFoodAmt(100);
    assertNotEquals(m101, new Menu(3001, "Idli", 2001, "VEG", "35", 39));
    assertEquals(m100, new Menu(3001, "Idli", 2001, "VEG", "35", 39));
    assertEquals(m100.hashCode(), new Menu(3001, "Idli", 2001, "VEG", "35", 39).hashCode());
    assertEquals(m100.toString(), new Menu(3001, "Idli", 2001, "VEG", "35", 39).toString());
  }
  // /**
  //  * tests that empty Menu list is handled correctly.
  //  * @param dao mocking the dao class
  //  */
  // @Test
  // public final void testListAllEmpty(@Mocked final MenuDAO dao) {
  //   new Expectations() {
  //     {
  //       dao.show(); result = new ArrayList<Menu>();
  //     }
  //   };
  //   new MockUp<MenuFactory>() {
  //     @Mock
  //     MenuDAO dao() {
  //       return dao;
  //     }
  //   };
  //   Menu[] me = MenuFactory.showMenu();
  //   assertEquals(0, me.length);
  // }
  /**
   * Tests that a list with some Menus is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllSome(@Mocked final MenuDAO dao) {
    final Menu m100 = new Menu(3001, "Idli", 2001, "VEG", "35", 39);
    final ArrayList<Menu> mn = new ArrayList<Menu>();
    new Expectations() {
      {
        mn.add(m100);
        dao.validateMenuId(3001);
        result = mn;
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };
    Menu mn1 = MenuFactory.validateMenuId(3001);
    //Menu mn2 = MenuFactory.validateMenuId(3002);
    assertEquals(m100.getFoodId(), mn1.getFoodId());

    assertEquals(mn1.getFoodId(),
        mn1.getFoodId());

    assertEquals(m100.getFoodName(),
        mn1.getFoodName());

    assertEquals(m100.getVenId(),
        mn1.getVenId());

    assertEquals(m100.getFoodType(),
        mn1.getFoodType());

    assertEquals(m100.getCalories(),
        mn1.getCalories());

    assertEquals(m100.getFoodAmt(),
        mn1.getFoodAmt(), 0.5e-2);

    Menu[] me = MenuFactory.showMenu();
    //assertEquals(2, me.length);
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodId(),
        mn1.getFoodId());
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodName(),
        mn1.getFoodName());
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getVenId(),
        mn1.getVenId());
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodType(),
        mn1.getFoodType());
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getCalories(),
        mn1.getCalories());
    assertEquals(new Menu(3001, "Idli", 2001, "VEG", "35", 39).getFoodAmt(),
        mn1.getFoodAmt(), 0.001);
  }
/**
 * @param dao ghjg.
 */
  @Test
  public final void testListAllEmpty(@Mocked final MenuDAO dao) {
    new Expectations() {
      {
        dao.show();
        result = new ArrayList<Menu>();
      }
    };
    new MockUp<MenuFactory>() {
      @Mock
      MenuDAO dao() {
        return dao;
      }
    };
    Menu[] me = MenuFactory.showMenu();
    assertEquals(0, me.length);
  }

    /**
   * test dao.
   */
  @Test
  public final void testDao() {
    Menu[] eArray = MenuFactory.showMenu();
    assertNotNull(eArray);
  }
}
