#### Desktop

  * Gitbash
  * Cygwin w/ Curl, Netstat
  * MySQL Server
  * MySQL Workbench
  * Java JDK
  * Maven
  * Tomcat
  * Angular w/ dependencies: node, npm
  * Chrome w/ Augury 4.4.4+ installed
  * VS Code
  * Jenkin
 
#### AWS CodeCommit

  * A skeletal repository which the trainee teams can clone, build and execute to get a basic application

 